/**
 * Fringe Analysis — main script
 * - Mobile menu + dropdown arrows (parents always navigate)
 * - Comments + likes (localStorage, works on GitHub Pages)
 */

(function () {
  'use strict';

  // ——— Mobile menu ———
  const menuToggle = document.getElementById('menuToggle');
  const mainNav = document.getElementById('mainNav');

  if (menuToggle && mainNav) {
    menuToggle.addEventListener('click', () => {
      mainNav.classList.toggle('open');
    });
  }

  // On mobile: arrow toggles dropdown, text link navigates
  document.querySelectorAll('.nav-item').forEach(item => {
    const dropdown = item.querySelector('.dropdown');
    if (!dropdown) return;

    // Insert arrow button if not present
    let arrowBtn = item.querySelector('.nav-arrow-btn');
    if (!arrowBtn) {
      arrowBtn = document.createElement('button');
      arrowBtn.type = 'button';
      arrowBtn.className = 'nav-arrow-btn';
      arrowBtn.setAttribute('aria-label', 'Показать подразделы');
      arrowBtn.textContent = '▾';
      const link = item.querySelector('.nav-link');
      if (link) {
        // Remove existing arrow span from link text for cleaner mobile
        const span = link.querySelector('.arrow');
        if (span) span.style.display = 'none';
        link.after(arrowBtn);
      }
    }

    arrowBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      item.classList.toggle('open');
      arrowBtn.textContent = item.classList.contains('open') ? '▴' : '▾';
    });
  });

  // ——— Comments + Likes (localStorage) ———
  const commentsRoot = document.getElementById('comments-root');
  if (!commentsRoot) return;

  const pageKey = 'fa_comments_' + (location.pathname.replace(/\/$/, '') || '/index.html');

  function loadComments() {
    try {
      return JSON.parse(localStorage.getItem(pageKey) || '[]');
    } catch {
      return [];
    }
  }

  function saveComments(list) {
    localStorage.setItem(pageKey, JSON.stringify(list));
  }

  function formatDate(iso) {
    const d = new Date(iso);
    return d.toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  function render() {
    const list = loadComments();
    const container = commentsRoot.querySelector('.comments-list');
    if (!container) return;

    if (list.length === 0) {
      container.innerHTML = '<div class="comments-empty">Пока нет комментариев. Будьте первым!</div>';
      return;
    }

    container.innerHTML = list
      .slice()
      .reverse()
      .map((c, idx) => {
        const realIdx = list.length - 1 - idx;
        return `
        <div class="comment-item" data-id="${c.id}">
          <div class="comment-header">
            <span class="comment-author">${escapeHtml(c.name)}</span>
            <span class="comment-date">${formatDate(c.date)}</span>
          </div>
          <div class="comment-body">${escapeHtml(c.text)}</div>
          <div class="comment-actions">
            <button type="button" class="like-btn ${c.likedByMe ? 'liked' : ''}" data-idx="${realIdx}">
              <span class="heart">${c.likedByMe ? '♥' : '♡'}</span>
              <span class="count">${c.likes || 0}</span>
            </button>
          </div>
        </div>`;
      })
      .join('');

    container.querySelectorAll('.like-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = parseInt(btn.dataset.idx, 10);
        const comments = loadComments();
        if (!comments[i]) return;
        if (comments[i].likedByMe) {
          comments[i].likes = Math.max(0, (comments[i].likes || 1) - 1);
          comments[i].likedByMe = false;
        } else {
          comments[i].likes = (comments[i].likes || 0) + 1;
          comments[i].likedByMe = true;
        }
        saveComments(comments);
        render();
      });
    });
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // Form submit
  const form = commentsRoot.querySelector('#comment-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = (form.querySelector('[name="name"]').value || '').trim();
      const text = (form.querySelector('[name="text"]').value || '').trim();
      if (!name || !text) return;

      const comments = loadComments();
      comments.push({
        id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
        name,
        text,
        date: new Date().toISOString(),
        likes: 0,
        likedByMe: false
      });
      saveComments(comments);
      form.reset();
      render();
    });
  }

  render();
})();
